﻿using System;
using System.Linq;
using System.Text;

namespace Model
{
    ///<summary>
    ///
    ///</summary>
    public partial class XtMenuAll
    {
           public XtMenuAll(){

            this.mLast =Convert.ToByte("0");
            this.FormType =Convert.ToString("1");
            this.Ver =Convert.ToString("0");
            this.IsCanUse =Convert.ToString("Y");

           }
           /// <summary>
           /// Desc:功能编码
           /// Default:
           /// Nullable:False
           /// </summary>           
           public string FunCode {get;set;}

           /// <summary>
           /// Desc:功能名称
           /// Default:
           /// Nullable:False
           /// </summary>           
           public string FunName {get;set;}

           /// <summary>
           /// Desc:级别
           /// Default:
           /// Nullable:False
           /// </summary>           
           public byte mClass {get;set;}

           /// <summary>
           /// Desc:是否末级
           /// Default:0
           /// Nullable:False
           /// </summary>           
           public byte mLast {get;set;}

           /// <summary>
           /// Desc:暂无功能
           /// Default:
           /// Nullable:True
           /// </summary>           
           public string DllName {get;set;}

           /// <summary>
           /// Desc:暂无功能
           /// Default:
           /// Nullable:True
           /// </summary>           
           public string DllFun {get;set;}

           /// <summary>
           /// Desc:0-嵌入框中 1-弹出框
           /// Default:1
           /// Nullable:False
           /// </summary>           
           public string FormType {get;set;}

           /// <summary>
           /// Desc:暂时无用
           /// Default:0
           /// Nullable:False
           /// </summary>           
           public string Ver {get;set;}

           /// <summary>
           /// Desc:默认Y
           /// Default:Y
           /// Nullable:False
           /// </summary>           
           public string IsCanUse {get;set;}

           /// <summary>
           /// Desc:备注
           /// Default:
           /// Nullable:True
           /// </summary>           
           public string Remark {get;set;}

    }
}
