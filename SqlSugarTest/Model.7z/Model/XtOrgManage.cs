﻿using System;
using System.Linq;
using System.Text;

namespace Model
{
    ///<summary>
    ///
    ///</summary>
    public partial class XtOrgManage
    {
           public XtOrgManage(){


           }
           /// <summary>
           /// Desc:组织编码
           /// Default:
           /// Nullable:False
           /// </summary>           
           public string OrgCode {get;set;}

           /// <summary>
           /// Desc:组织名称
           /// Default:
           /// Nullable:False
           /// </summary>           
           public string OrgName {get;set;}

           /// <summary>
           /// Desc:组织类型
           /// Default:
           /// Nullable:False
           /// </summary>           
           public string Orgtype {get;set;}

           /// <summary>
           /// Desc:组织级别
           /// Default:
           /// Nullable:False
           /// </summary>           
           public string Orgclass {get;set;}

    }
}
