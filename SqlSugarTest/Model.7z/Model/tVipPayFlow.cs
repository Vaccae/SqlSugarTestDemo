﻿using System;
using System.Linq;
using System.Text;

namespace Model
{
    ///<summary>
    ///
    ///</summary>
    public partial class tVipPayFlow
    {
           public tVipPayFlow(){


           }
           /// <summary>
           /// Desc:会员编码
           /// Default:
           /// Nullable:True
           /// </summary>           
           public string Vipno {get;set;}

           /// <summary>
           /// Desc:站点编码
           /// Default:
           /// Nullable:True
           /// </summary>           
           public string PosNo {get;set;}

           /// <summary>
           /// Desc:组织编码
           /// Default:
           /// Nullable:True
           /// </summary>           
           public string OrgCode {get;set;}

           /// <summary>
           /// Desc:流水号
           /// Default:
           /// Nullable:True
           /// </summary>           
           public string SerialNo {get;set;}

           /// <summary>
           /// Desc:银行消费流水号
           /// Default:
           /// Nullable:True
           /// </summary>           
           public string bankno {get;set;}

           /// <summary>
           /// Desc:消费日期
           /// Default:
           /// Nullable:False
           /// </summary>           
           public DateTime sa_date {get;set;}

           /// <summary>
           /// Desc:消费时间
           /// Default:
           /// Nullable:False
           /// </summary>           
           public string sa_time {get;set;}

           /// <summary>
           /// Desc:应付金额
           /// Default:
           /// Nullable:False
           /// </summary>           
           public decimal Amount {get;set;}

           /// <summary>
           /// Desc:实付金额
           /// Default:
           /// Nullable:False
           /// </summary>           
           public decimal payAmount {get;set;}

           /// <summary>
           /// Desc:操作标志（暂时无用）
           /// Default:
           /// Nullable:True
           /// </summary>           
           public string RighgFlag {get;set;}

           /// <summary>
           /// Desc:备注
           /// Default:
           /// Nullable:True
           /// </summary>           
           public string Remark {get;set;}

           /// <summary>
           /// Desc:（暂时无用）
           /// Default:
           /// Nullable:True
           /// </summary>           
           public string pFlag {get;set;}

    }
}
