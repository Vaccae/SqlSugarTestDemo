﻿using System;
using System.Linq;
using System.Text;

namespace Model
{
    ///<summary>
    ///
    ///</summary>
    public partial class XtSysCfg
    {
           public XtSysCfg(){

            this.CsValue =Convert.ToString("");

           }
           /// <summary>
           /// Desc:参数类型
           /// Default:
           /// Nullable:False
           /// </summary>           
           public string Section {get;set;}

           /// <summary>
           /// Desc:参数名称
           /// Default:
           /// Nullable:False
           /// </summary>           
           public string CsName {get;set;}

           /// <summary>
           /// Desc:参数值
           /// Default:
           /// Nullable:False
           /// </summary>           
           public string CsValue {get;set;}

    }
}
