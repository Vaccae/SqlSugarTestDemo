﻿using System;
using System.Linq;
using System.Text;

namespace Model
{
    ///<summary>
    ///车型表
    ///</summary>
    public partial class tVipCarType
    {
           public tVipCarType(){

            this.Disc =Convert.ToDecimal("100");
            this.Amount =Convert.ToDecimal("0");

           }
           /// <summary>
           /// Desc:车型编码
           /// Default:
           /// Nullable:False
           /// </summary>           
           public string TypeCode {get;set;}

           /// <summary>
           /// Desc:车型名称
           /// Default:
           /// Nullable:False
           /// </summary>           
           public string TypeName {get;set;}

           /// <summary>
           /// Desc:折扣
           /// Default:100
           /// Nullable:False
           /// </summary>           
           public decimal Disc {get;set;}

           /// <summary>
           /// Desc:金额
           /// Default:0
           /// Nullable:False
           /// </summary>           
           public decimal Amount {get;set;}

           /// <summary>
           /// Desc:备注
           /// Default:
           /// Nullable:True
           /// </summary>           
           public string remark {get;set;}

    }
}
