﻿using System;
using System.Linq;
using System.Text;

namespace Model
{
    ///<summary>
    ///
    ///</summary>
    public partial class XtMuser
    {
           public XtMuser(){

            this.Stat =Convert.ToString("0");
            this.ZzStat =Convert.ToString("0");

           }
           /// <summary>
           /// Desc:用户编码
           /// Default:
           /// Nullable:False
           /// </summary>           
           public string UserCode {get;set;}

           /// <summary>
           /// Desc:用户名称
           /// Default:
           /// Nullable:False
           /// </summary>           
           public string UserName {get;set;}

           /// <summary>
           /// Desc:密码
           /// Default:
           /// Nullable:True
           /// </summary>           
           public string mpassword {get;set;}

           /// <summary>
           /// Desc:性别
           /// Default:
           /// Nullable:True
           /// </summary>           
           public string Sex {get;set;}

           /// <summary>
           /// Desc:组织编码
           /// Default:
           /// Nullable:True
           /// </summary>           
           public string OrgCode {get;set;}

           /// <summary>
           /// Desc:状态 0-未启用 1-启用
           /// Default:0
           /// Nullable:False
           /// </summary>           
           public string Stat {get;set;}

           /// <summary>
           /// Desc:证件类型
           /// Default:
           /// Nullable:True
           /// </summary>           
           public string IDtype {get;set;}

           /// <summary>
           /// Desc:证件编码
           /// Default:
           /// Nullable:True
           /// </summary>           
           public string IDCard {get;set;}

           /// <summary>
           /// Desc:生日
           /// Default:
           /// Nullable:True
           /// </summary>           
           public DateTime? Birthday {get;set;}

           /// <summary>
           /// Desc:学历
           /// Default:
           /// Nullable:True
           /// </summary>           
           public string Education {get;set;}

           /// <summary>
           /// Desc:地址
           /// Default:
           /// Nullable:True
           /// </summary>           
           public string Address {get;set;}

           /// <summary>
           /// Desc:电话
           /// Default:
           /// Nullable:True
           /// </summary>           
           public string Phone {get;set;}

           /// <summary>
           /// Desc:手机
           /// Default:
           /// Nullable:True
           /// </summary>           
           public string Mobile {get;set;}

           /// <summary>
           /// Desc:邮箱
           /// Default:
           /// Nullable:True
           /// </summary>           
           public string Email {get;set;}

           /// <summary>
           /// Desc:暂无用
           /// Default:
           /// Nullable:True
           /// </summary>           
           public string Degree {get;set;}

           /// <summary>
           /// Desc:暂无用
           /// Default:
           /// Nullable:True
           /// </summary>           
           public DateTime? GsDate {get;set;}

           /// <summary>
           /// Desc:转正日期（暂无用）
           /// Default:
           /// Nullable:True
           /// </summary>           
           public DateTime? ZzDate {get;set;}

        /// <summary>
        /// Desc:离职日期（暂无用）
        /// Default:
        /// Nullable:True
        /// </summary>           
        public DateTime? LzDate {get;set;}

           /// <summary>
           /// Desc:
           /// Default:0
           /// Nullable:False
           /// </summary>           
           public string ZzStat {get;set;}

           /// <summary>
           /// Desc:备注
           /// Default:
           /// Nullable:True
           /// </summary>           
           public string remark {get;set;}

           /// <summary>
           /// Desc:录入日期
           /// Default:
           /// Nullable:False
           /// </summary>           
           public DateTime lrdate {get;set;}

           /// <summary>
           /// Desc:录入人
           /// Default:
           /// Nullable:False
           /// </summary>           
           public string lrpep {get;set;}

           /// <summary>
           /// Desc:修改日期
           /// Default:
           /// Nullable:False
           /// </summary>           
           public DateTime xgdate {get;set;}

           /// <summary>
           /// Desc:修改人
           /// Default:
           /// Nullable:False
           /// </summary>           
           public string xgpep {get;set;}

    }
}
