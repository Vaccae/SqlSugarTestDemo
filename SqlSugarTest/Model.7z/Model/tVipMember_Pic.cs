﻿using System;
using System.Linq;
using System.Text;

namespace Model
{
    ///<summary>
    ///
    ///</summary>
    public partial class tVipMember_Pic
    {
           public tVipMember_Pic(){


           }
           /// <summary>
           /// Desc:会员编码
           /// Default:
           /// Nullable:False
           /// </summary>           
           public string VipNO {get;set;}

           /// <summary>
           /// Desc:照片序号
           /// Default:
           /// Nullable:False
           /// </summary>           
           public int Photoidx {get;set;}

           /// <summary>
           /// Desc:照片
           /// Default:
           /// Nullable:True
           /// </summary>           
           public byte[] Photo {get;set;}

    }
}
