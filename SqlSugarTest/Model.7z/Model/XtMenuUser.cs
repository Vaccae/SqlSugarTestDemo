﻿using System;
using System.Linq;
using System.Text;

namespace Model
{
    ///<summary>
    ///
    ///</summary>
    public partial class XtMenuUser
    {
        public XtMenuUser()
        {


        }
        /// <summary>
        /// Desc:用户编码
        /// Default:
        /// Nullable:False
        /// </summary>           
        public string UserCode { get; set; }

        /// <summary>
        /// Desc:功能编码
        /// Default:
        /// Nullable:False
        /// </summary>           
        public string FunCode { get; set; }

        /// <summary>
        /// Desc:级别
        /// Default:
        /// Nullable:False
        /// </summary>           
        public byte mClass { get; set; }

        /// <summary>
        /// Desc:是否末级
        /// Default:
        /// Nullable:False
        /// </summary>           
        public byte mLast { get; set; }

        /// <summary>
        /// Desc:默认1
        /// Default:
        /// Nullable:False
        /// </summary>           
        public string IsGrant { get; set; }

        /// <summary>
        /// Desc:允许添加 1-允许 0-不允许
        /// Default:
        /// Nullable:False
        /// </summary>           
        public string IsInsert { get; set; }

        /// <summary>
        /// Desc:允许修改 1-允许 0-不允许
        /// Default:
        /// Nullable:False
        /// </summary>           
        public string IsUpdate { get; set; }

        /// <summary>
        /// Desc:允许删除 1-允许 0-不允许
        /// Default:
        /// Nullable:False
        /// </summary>           
        public string IsDelete { get; set; }

        /// <summary>
        /// Desc:允许查询 1-允许 0-不允许
        /// Default:
        /// Nullable:False
        /// </summary>           
        public string IsQuery { get; set; }

        /// <summary>
        /// Desc:允许打印 1-允许 0-不允许
        /// Default:
        /// Nullable:False
        /// </summary>           
        public string IsPrint { get; set; }

        /// <summary>
        /// Desc:允许审核 1-允许 0-不允许
        /// Default:
        /// Nullable:False
        /// </summary>           
        public string IsAffirm { get; set; }

        /// <summary>
        /// Desc:允许设计报表 1-允许 0-不允许
        /// Default:
        /// Nullable:False
        /// </summary>           
        public string isDsnRpt { get; set; }

        /// <summary>
        /// Desc:暂无用
        /// Default:
        /// Nullable:False
        /// </summary>           
        public string IsIprc { get; set; }

        /// <summary>
        /// Desc:允许导出 1-允许  0-不允许 
        /// Default:
        /// Nullable:False
        /// </summary>           
        public string IsExport { get; set; }

    }
}
