﻿using System;
using System.Linq;
using System.Text;

namespace Model
{
    ///<summary>
    ///站点设置
    ///</summary>
    public partial class POS
    {
           public POS(){


           }
           /// <summary>
           /// Desc:站点号
           /// Default:
           /// Nullable:False
           /// </summary>           
           public string Posno {get;set;}

           /// <summary>
           /// Desc:站点名称
           /// Default:
           /// Nullable:False
           /// </summary>           
           public string Posname {get;set;}

           /// <summary>
           /// Desc:组织编码
           /// Default:
           /// Nullable:True
           /// </summary>           
           public string OrgCode {get;set;}

           /// <summary>
           /// Desc:状态
           /// Default:1-正常使用 0-禁用
           /// Nullable:True
           /// </summary>           
           public string status {get;set;}

    }
}
